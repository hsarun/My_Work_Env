#!/bin/bash

vhdl $1
