#! /usr/bin/python
import subprocess
import os

base = '/home/spatward/ws/'

def update_workspace(br):
#    cmd = []
    cmd = ""
    wp_path = base + br
    panos=wp_path + "/panos/"
    cmd=""
    cmd+="ls -ltr"
    print("Cmd is ", cmd)
    p=subprocess.Popen("ls -ltr", cwd=panos, shell=True)
    p.wait()
#    cmd=""
#    cmd+="git show"
#    print("Cmd is ", cmd)
#    p=subprocess.Popen(cmd, cwd=panos, shell=True)
    cmd=""
    cmd+="git up"
    print("Cmd is ", cmd)
    p=subprocess.Popen(cmd, cwd=panos, shell=True)
    p.wait()
    vhdl=wp_path + "/vhdl"
    print("vhdl path", vhdl);
#    p=subprocess.Popen("ls -ltr", cwd=vhdl, shell=True)
    cmd=""
    cmd+="bash -c \'source /home/spatward/scripts/run_vhdl.sh " + br + "\'" 
    print("Cmd is ", cmd)
    #p=subprocess.Popen([cmd, br], shell=True, executable='/bin/bash')
    os.system(cmd);
    p.wait()
    p=subprocess.Popen("env|grep vhdl", shell=True)
    p.wait()
    cmd=""
    cmd+="cvsup"
    print("Cmd is ", cmd)
#    print subprocess.Popen(cmd, cwd=vhdl, shell=True)

update_workspace("tb-MG10S")
