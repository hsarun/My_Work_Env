#! /usr/bin/python
import sys  
import os

#def init():


def compare_f(filepath_result, filepath_compare):
   result = 0
   words = {}
   fr = open(filepath_result)
   fc = open(filepath_compare)

   line_r = fr.readline()
   line_c = fc.readline()

   while line_r != '' or line_c != '':
       word_r = line_r.split()
       word_c = line_c.split()
       for i in range(0,4,1):
           if i < len(word_r) and i < len(word_c):
                #print( "comparing {0} and {1}".format(word_r[i], word_c[i]))
                if word_r[i] != word_c[i] :
                   result = 1
       line_r = fr.readline()
       line_c = fc.readline()
   
   return result 
       

def main(): 
   result = 0 
   filepath_result = sys.argv[1]
   filepath_compare = sys.argv[2]

   if not os.path.isfile(filepath_result):
       print("File path {0} does not exist. Exiting...".format(filepath_result))
       sys.exit()
   if not os.path.isfile(filepath_compare):
       print("File path {0} does not exist. Exiting...".format(filepath_compare))
       sys.exit()

   result = compare_f(filepath_result, filepath_compare)

   if result == 1:
       print("COMPARE FAILED") 
   else :
       print("COMPARE SUCCESSFUL") 
    

if __name__ == '__main__':  
   main()
